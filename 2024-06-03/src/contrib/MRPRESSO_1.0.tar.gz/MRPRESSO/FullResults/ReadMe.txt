The file MR-PRESSOpaper_FullResults.xlsx contains the complete set of results from the MR-PRESSO paper. Two tabs describe respectively:
1) a glossary of the traits
2) results of the MR-PRESSO method which detects and corrects for horizontal pleiotropy.
