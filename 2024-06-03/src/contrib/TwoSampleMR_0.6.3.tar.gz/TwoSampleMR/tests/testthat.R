library(testthat)
library(TwoSampleMR)

test_check("TwoSampleMR")
