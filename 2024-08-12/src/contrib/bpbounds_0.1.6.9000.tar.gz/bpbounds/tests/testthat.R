library(testthat)
library(bpbounds)

test_check("bpbounds")
