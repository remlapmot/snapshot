library(testthat)
library(knitexercise)

test_check("knitexercise")
