# tmsens 0.3.0

* Simplified the NAMESPACE so functions from other packages are not imported

* Modified the `tm()` helpfile example to run faster

# tmsens 0.2.0

* Bump roxygen2 version

* Update maintainer email address

# tmsens 0.1.0

* Initial submission to CRAN
