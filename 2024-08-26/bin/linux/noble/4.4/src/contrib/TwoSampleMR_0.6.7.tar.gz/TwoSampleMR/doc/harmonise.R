## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  cache = TRUE
)

## ----message=FALSE------------------------------------------------------------
library(TwoSampleMR)

## ----echo=FALSE, eval=FALSE, warning=FALSE------------------------------------
#  # Get all required data
#  ao <- available_outcomes()
#  bmi_exp_dat <- extract_instruments(outcomes = 'ieu-a-2')
#  chd_out_dat <- extract_outcome_data(snps = bmi_exp_dat$SNP, outcomes = 'ieu-a-7')
#  save(ao, bmi_exp_dat, chd_out_dat, file = file.path("inst", "extdata", "vig_harmonise.RData"), compress = "xz")

## ----echo=FALSE, eval=TRUE, warning=FALSE-------------------------------------
load(system.file("extdata", "vig_harmonise.RData", package = "TwoSampleMR"))

## ----eval=FALSE---------------------------------------------------------------
#  bmi_exp_dat <- extract_instruments(outcomes = 'ieu-a-2')
#  chd_out_dat <- extract_outcome_data(snps = bmi_exp_dat$SNP, outcomes = 'ieu-a-7')

## -----------------------------------------------------------------------------
dat <- harmonise_data(
	exposure_dat = bmi_exp_dat, 
	outcome_dat = chd_out_dat
)

## ----eval=FALSE---------------------------------------------------------------
#  ao <- available_outcomes()

## -----------------------------------------------------------------------------
ao[ao$trait == "Body mass index", c("trait", "id", "pmid", "author", "sample_size", "nsnp")]
ao[ao$trait == "Coronary heart disease", c("trait", "id", "pmid", "author", "ncase", "ncontrol", "nsnp")]

## ----eval=FALSE---------------------------------------------------------------
#  dat <- power_prune(dat, method = 1, dist.outcome = "binary")

## ----eval=FALSE---------------------------------------------------------------
#  dat <- power_prune(dat, method = 2, dist.outcome = "binary")

