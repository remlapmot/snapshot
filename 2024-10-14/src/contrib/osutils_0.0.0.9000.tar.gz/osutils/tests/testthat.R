library(testthat)
library(osutils)

test_check("osutils")

