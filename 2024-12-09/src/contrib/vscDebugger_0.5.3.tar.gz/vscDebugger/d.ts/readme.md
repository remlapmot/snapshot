
## Typescript declaration files

These files do not have any actual effect on the package itself.
Instead, they document the types and structures of the most important R functions used.
They are meant to document some functions and keep track of the content of (custom) protocol messages etc..
Most `.d.ts` files correspond to an `.R` file of the same name.
