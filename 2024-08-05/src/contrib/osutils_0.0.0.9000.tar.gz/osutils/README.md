# osutils
 
<!-- badges: start -->
[![R-CMD-check](https://github.com/wjchulme/osutils/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/wjchulme/osutils/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->
 
 Utility functions that help with common tasks in OpenSAFELY
