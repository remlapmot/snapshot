# RadialMR v1.1

* Fixed warning in `plotly_radial()`

* Helpfile examples are now conditional on the use of packages in the Suggests list

# RadialMR v1.0

* Initial release of package
