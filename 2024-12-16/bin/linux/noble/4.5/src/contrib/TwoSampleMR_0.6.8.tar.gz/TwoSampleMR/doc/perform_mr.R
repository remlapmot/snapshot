## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  cache = TRUE,
  fig.align = 'center'
)

## ----message=FALSE------------------------------------------------------------
library(TwoSampleMR)
library(ggplot2)

## ----eval=FALSE, echo=FALSE---------------------------------------------------
# ao <- available_outcomes()
# bmi_exp_dat <- extract_instruments(outcomes = 'ieu-a-2')
# chd_out_dat <- extract_outcome_data(snps = bmi_exp_dat$SNP, outcomes = 'ieu-a-7')
# id_exposure <- c("ieu-a-299", "ieu-a-300", "ieu-a-302")
# id_outcome <- "ieu-a-7"
# mv_exposure_dat <- mv_extract_exposures(id_exposure)
# mv_outcome_dat <- extract_outcome_data(mv_exposure_dat$SNP, id_outcome)
# snplist <- c("rs234", "rs1205")
# ld_mat <- ld_matrix(snplist)
# save(ao, bmi_exp_dat, chd_out_dat, mv_exposure_dat, mv_outcome_dat, ld_mat, file = file.path("inst", "extdata", "vig_perform_mr.RData"), compress = "xz")

## ----echo=FALSE, eval=TRUE, warning=FALSE-------------------------------------
load(system.file("extdata", "vig_perform_mr.RData", package = "TwoSampleMR"))

## ----eval=FALSE---------------------------------------------------------------
# bmi_exp_dat <- extract_instruments(outcomes = 'ieu-a-2')
# chd_out_dat <- extract_outcome_data(snps = bmi_exp_dat$SNP, outcomes = 'ieu-a-7')

## -----------------------------------------------------------------------------
dat <- harmonise_data(bmi_exp_dat, chd_out_dat)

## -----------------------------------------------------------------------------
res <- mr(dat)
res

## -----------------------------------------------------------------------------
mr_method_list()

## -----------------------------------------------------------------------------
mr(dat, method_list = c("mr_egger_regression", "mr_ivw"))

## -----------------------------------------------------------------------------
mr_heterogeneity(dat)

## -----------------------------------------------------------------------------
mr_heterogeneity(dat, method_list = c("mr_egger_regression", "mr_ivw"))

## -----------------------------------------------------------------------------
mr_pleiotropy_test(dat)

## -----------------------------------------------------------------------------
res_single <- mr_singlesnp(dat)

## -----------------------------------------------------------------------------
res_single <- mr_singlesnp(dat, single_method = "mr_meta_fixed")

## -----------------------------------------------------------------------------
res_single <- mr_singlesnp(dat, all_method = "mr_two_sample_ml")

## -----------------------------------------------------------------------------
res_loo <- mr_leaveoneout(dat)

## -----------------------------------------------------------------------------
res <- mr(dat)
p1 <- mr_scatter_plot(res, dat)

## ----fig.alt="A scatter plot visualising the two-sample data points and the following fitted models; Inverse Variance Weighted, MR-Egger, Simple mode, Weighted median, and Weighted mode.", fig.asp=1.15----
p1[[1]]

## -----------------------------------------------------------------------------
length(p1)

## -----------------------------------------------------------------------------
res <- mr(dat, method_list = c("mr_egger_regression", "mr_ivw"))
p1 <- mr_scatter_plot(res, dat)

## ----eval=FALSE---------------------------------------------------------------
# ggsave(p1[[1]], file = "filename.pdf", width = 7, height = 7)

## ----eval=FALSE---------------------------------------------------------------
# ggsave(p1[[1]], file = "filename.png", width = 7, height = 7)

## ----fig.alt="A forest plot showing the estimated causal effects using each SNP separately, and the Inverse Variance Weighted and MR-Egger estimates using all the SNPs.", warning=FALSE, fig.height=10----
res_single <- mr_singlesnp(dat)
p2 <- mr_forest_plot(res_single)
p2[[1]]

## ----fig.alt="An alternative forest plot showing the estimated causal effects using each SNP separately, and the Inverse Variance Weighted and Maximum Likelihood estimates using all the SNPs.", warning=FALSE, fig.height=10----
res_single <- mr_singlesnp(dat, all_method = c("mr_ivw", "mr_two_sample_ml"))
p2 <- mr_forest_plot(res_single)
p2[[1]]

## ----fig.alt="A leave one out plot showing the Inverse Variance Weighted estimate with each SNP omitted.", warning=FALSE, fig.height=10----
res_loo <- mr_leaveoneout(dat)
p3 <- mr_leaveoneout_plot(res_loo)
p3[[1]]

## ----fig.alt="A funnel plot showing the causal effect for each SNP and the inverse variance weighted and MR-Egger estimates using all the SNPs.", fig.asp=1.15----
res_single <- mr_singlesnp(dat)
p4 <- mr_funnel_plot(res_single)
p4[[1]]

## ----cache=FALSE, warning=FALSE, eval=FALSE-----------------------------------
# exp_dat <- extract_instruments(outcomes = c(2, 100, 1032, 104, 1, 72, 999))
# table(exp_dat$exposure)
# chd_out_dat <- extract_outcome_data(
#   snps = exp_dat$SNP,
#   outcomes = 7
# )
# 
# dat2 <- harmonise_data(
#   exposure_dat = exp_dat,
#   outcome_dat = chd_out_dat
# )
# res <- mr(dat2)

## ----cache=FALSE, warning=FALSE, eval=FALSE-----------------------------------
# res <- subset_on_method(res) # default is to subset on either the IVW method (>1 instrumental SNP) or Wald ratio method (1 instrumental SNP).
# res <- sort_1_to_many(res, b = "b", sort_action = 4) # this sorts results by decreasing effect size (largest effect at top of the plot)
# res <- split_exposure(res) # to keep the Y axis label clean we exclude the exposure ID labels from the exposure column
# res$weight <- 1/res$se
# 
# min(exp(res$b - 1.96*res$se)) # identify value for 'lo' in forest_plot_1_to_many
# max(exp(res$b + 1.96*res$se)) # identify value for 'up' in forest_plot_1_to_many
# 
# forest_plot_1_to_many(
#   res,
#   b = "b",
#   se = "se",
#   exponentiate = TRUE,
#   ao_slc = FALSE,
#   lo = 0.3,
#   up = 2.5,
#   TraitM = "exposure",
#   col1_width = 2,
#   by = NULL,
#   trans = "log2",
#   xlab = "OR for CHD per SD increase in risk factor (95% confidence interval)",
#   weight = "weight"
# )

## ----cache=FALSE, warning=FALSE, message=FALSE, eval=FALSE--------------------
# res$pval<-formatC(res$pval, format = "e", digits = 2)
# forest_plot_1_to_many(
#   res,
#   b = "b",
#   se = "se",
#   exponentiate = TRUE,
#   ao_slc = FALSE,
#   lo = 0.3,
#   up = 2.5,
#   TraitM = "exposure",
#   by = NULL,
#   trans = "log2",
#   xlab = "OR for CHD per SD increase in risk factor (95% CI)",
#   weight = "weight",
#   subheading_size = 11,
#   col1_title = "Risk factor",
#   col1_width = 2.5,
#   col_text_size = 4,
#   addcols = c("nsnp", "pval"),
#   addcol_widths = c(1.0, 1.0),
#   addcol_titles = c("No. SNPs", "P-val")
# )

## ----cache=FALSE, warning=FALSE,message=FALSE, eval=FALSE---------------------
# forest_plot_1_to_many(
#   res,
#   b = "b",
#   se = "se",
#   exponentiate = TRUE,
#   ao_slc = FALSE,
#   lo = 0.3,
#   up = 3.0,
#   TraitM = "exposure",
#   col1_width = 2.0,
#   by = NULL,
#   trans = "log2",
#   xlab = "",
#   addcols = c("nsnp", "pval"),
#   weight = "weight",
#   col_text_size = 4,
#   addcol_widths = c(0.5, 1.0),
#   addcol_titles = c("", "")
# )

## ----cache=FALSE, warning=FALSE, fig.height=10, eval=FALSE--------------------
# res <- mr(dat2)
# res <- split_exposure(res) # to keep the Y axis label clean we exclude the exposure ID labels from the exposure column
# 
# res <-
#   sort_1_to_many(
#     res,
#     group = "exposure",
#     sort_action = 3,
#     priority = "Inverse variance weighted",
#     trait_m = "method"
#   )
# 
# forest_plot_1_to_many(
#   res,
#   b = "b",
#   se = "se",
#   exponentiate = TRUE,
#   trans = "log2",
#   ao_slc = FALSE,
#   lo = 0.03,
#   up = 22,
#   col1_width = 2,
#   by = "exposure",
#   TraitM = "method",
#   xlab = "OR for CHD per SD increase in risk factor (95% confidence interval)",
#   subheading_size = 12,
#   col_text_size = 4
# )

## ----cache=FALSE, warning=FALSE, eval=FALSE-----------------------------------
# res <- mr(dat2)
# res <- split_exposure(res)
# res <- subset_on_method(res)
# res$subcategory[res$exposure %in% c("Adiponectin", "Hip circumference", "Waist circumference")] <- "Group 1"
# res$subcategory[is.na(res$subcategory)] <- "Group 2"
# res$weight <- 1/res$se
# res <- sort_1_to_many(res, sort_action = 1, group = "subcategory")
# 
# forest_plot_1_to_many(
#   res,
#   b = "b",
#   se = "se",
#   exponentiate = TRUE,
#   trans = "log2",
#   ao_slc = FALSE,
#   lo = 0.3,
#   up = 2.5,
#   TraitM = "exposure",
#   col_text_size = 4,
#   col1_width = 1.5,
#   by = "subcategory",
#   xlab = "OR for CHD per SD increase in risk factor (95% confidence interval)",
#   subheading_size = 14,
#   weight = "weight"
# )

## ----echo=TRUE, warning=FALSE, message=FALSE, eval=FALSE----------------------
# exp_dat <- extract_instruments(outcomes = 2) # extract instruments for BMI
# ao <- available_outcomes()
# ao <- ao[ao$category == "Disease", ] # identify diseases
# ao <- ao[which(ao$ncase > 100), ]
# 
# dis_dat <- extract_outcome_data(
#   snps = exp_dat$SNP,
#   outcomes = ao$id
# )
# 
# dat3 <- harmonise_data(
#   exposure_dat = exp_dat,
#   outcome_dat = dis_dat
# )
# 
# res <- mr(dat3, method_list = c("mr_wald_ratio", "mr_ivw"))
# res <- split_outcome(res) # to keep the Y axis label clean we exclude the exposure ID labels from the exposure column
# 
# res <- sort_1_to_many(res, b = "b", sort_action = 4) # this sorts results by decreasing effect size (largest effect at top of the plot)

## ----warning=FALSE, fig.height=10, eval=FALSE---------------------------------
# res1 <- res[1:52, ]
# res2 <- res[53:103, ]
# 
# plot1 <- forest_plot_1_to_many(
#   res1,
#   b = "b",
#   se = "se",
#   exponentiate = TRUE,
#   trans = "log2",
#   ao_slc = FALSE,
#   lo = 0.004,
#   up = 461,
#   col1_width = 2,
#   TraitM = "outcome",
#   col_text_size = 3,
#   xlab = ""
# )
# 
# plot2 <- forest_plot_1_to_many(
#   res2,
#   b = "b",
#   se = "se",
#   exponentiate = TRUE,
#   trans = "log2",
#   ao_slc = FALSE,
#   lo = 0.004,
#   up = 461,
#   col1_width = 2,
#   TraitM = "outcome",
#   subheading_size = 11,
#   col_text_size = 3,
#   xlab = ""
# )
# 
# plot1
# plot2
# 
# pdf("plot1.pdf", height = 10, width = 8)
# plot1
# dev.off()

## ----eval=FALSE---------------------------------------------------------------
# res <- mr(dat, method_list = c("mr_raps"))

## ----eval=FALSE---------------------------------------------------------------
# res <-
#   mr(
#     dat,
#     method_list = c("mr_raps"),
#     parameters = list(over.dispersion = FALSE, loss.function = "l2")
#   )

## ----eval=FALSE---------------------------------------------------------------
# mr_report(dat)

## -----------------------------------------------------------------------------
out <- directionality_test(dat)
knitr::kable(out)

## ----eval=FALSE, warnings=FALSE-----------------------------------------------
# mr_steiger(
#   p_exp = dat$pval.exposure,
#   p_out = dat$pval.outcome,
#   n_exp = dat$samplesize.exposure,
#   n_out = dat$samplesize.outcome,
#   r_xxo = 1,
#   r_yyo = 1,
#   r_exp=0
# )

## ----eval=FALSE---------------------------------------------------------------
# id_exposure <- c("ieu-a-299", "ieu-a-300", "ieu-a-302")
# id_outcome <- "ieu-a-7"

## ----eval=FALSE---------------------------------------------------------------
# mv_exposure_dat <- mv_extract_exposures(id_exposure)

## ----eval=FALSE---------------------------------------------------------------
# mv_outcome_dat <- extract_outcome_data(exposure_dat$SNP, id_outcome)

## -----------------------------------------------------------------------------
mvdat <- mv_harmonise_data(mv_exposure_dat, mv_outcome_dat)

## -----------------------------------------------------------------------------
res <- mv_multiple(mvdat)

## ----eval=FALSE---------------------------------------------------------------
# snplist <- c("rs234", "rs1205")
# ld_mat <- ld_matrix(snplist)

## -----------------------------------------------------------------------------
ld_mat

## -----------------------------------------------------------------------------
dat <- harmonise_data(
  exposure_dat = bmi_exp_dat,
  outcome_dat = chd_out_dat
)

## -----------------------------------------------------------------------------
dat2 <- dat_to_MRInput(dat)

## ----eval=FALSE---------------------------------------------------------------
# MendelianRandomization::mr_ivw(dat2[[1]])

## ----eval=FALSE---------------------------------------------------------------
# dat2 <- dat_to_MRInput(dat, get_correlation = TRUE)
# MendelianRandomization::mr_ivw(dat2[[1]], correl = TRUE)

## ----eval=FALSE---------------------------------------------------------------
# # Extact instruments for BMI
# exposure_dat <- extract_instruments("ieu-a-2")
# 
# # Get corresponding effects for CHD
# outcome_dat <- extract_outcome_data(exposure_dat$SNP, "ieu-a-7")
# 
# # Harmonise
# dat <- harmonise_data(exposure_dat, outcome_dat)
# 
# # Load the downloaded RData object. This loads the rf object
# load("rf.rdata")
# 
# # Obtain estimates from all methods, and generate data metrics
# res_all <- mr_wrapper(dat)
# 
# # MR-MoE - predict the performance of each method
# res_moe <- mr_moe(res_all, rf)

## -----------------------------------------------------------------------------
head(res)

## -----------------------------------------------------------------------------
res <- mr(dat)
split_outcome(res)

## -----------------------------------------------------------------------------
generate_odds_ratios(res)

## -----------------------------------------------------------------------------
subset_on_method(res)

## ----eval=FALSE---------------------------------------------------------------
# res <- mr(dat)
# het <- mr_heterogeneity(dat)
# plt <- mr_pleiotropy_test(dat)
# sin <- mr_singlesnp(dat)
# all_res <-
#   combine_all_mrresults(
#     res,
#     het,
#     plt,
#     sin,
#     ao_slc = TRUE,
#     Exp = TRUE,
#     split.exposure = FALSE,
#     split.outcome = TRUE
#   )
# head(all_res[, c(
#   "Method",
#   "outcome",
#   "exposure",
#   "nsnp",
#   "b",
#   "se",
#   "pval",
#   "intercept",
#   "intercept_se",
#   "intercept_pval",
#   "Q",
#   "Q_df",
#   "Q_pval",
#   "consortium",
#   "ncase",
#   "ncontrol",
#   "pmid",
#   "population"
# )])

