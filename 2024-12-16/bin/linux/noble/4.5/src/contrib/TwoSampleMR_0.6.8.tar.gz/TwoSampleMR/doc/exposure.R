## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  cache = TRUE
)

## ----message=FALSE------------------------------------------------------------
library(TwoSampleMR)

## ----eval=FALSE, echo=FALSE---------------------------------------------------
# # Get data for the vignette
# ao <- available_outcomes()
# bmi2014_exp_dat <- extract_instruments(outcomes = 'ieu-a-2')
# bmi_exp_dat <- clump_data(bmi2014_exp_dat)
# save(ao, bmi_exp_dat, bmi2014_exp_dat, file = file.path("inst", "extdata", "vig_exposure.RData"), compress = "xz")

## ----echo=FALSE, eval=TRUE, warning=FALSE-------------------------------------
load(system.file("extdata", "vig_exposure.RData", package = "TwoSampleMR"))

## ----eval=TRUE----------------------------------------------------------------
bmi_file <- system.file("extdata", "bmi.txt", package = "TwoSampleMR")

## ----eval=TRUE----------------------------------------------------------------
bmi_exp_dat <- read_exposure_data(bmi_file)
head(bmi_exp_dat)

## -----------------------------------------------------------------------------
bmi2_file <- system.file("extdata/bmi.csv", package = "TwoSampleMR")

## -----------------------------------------------------------------------------
bmi_exp_dat <- read_exposure_data(
	filename = bmi2_file,
	sep = ",",
	snp_col = "rsid",
	beta_col = "effect",
	se_col = "SE",
	effect_allele_col = "a1",
	other_allele_col = "a2",
	eaf_col = "a1_freq",
	pval_col = "p-value",
	units_col = "Units",
	gene_col = "Gene",
	samplesize_col = "n"
)
head(bmi_exp_dat)

## -----------------------------------------------------------------------------
bmi_exp_dat$exposure <- "BMI"

## -----------------------------------------------------------------------------
random_df <- data.frame(
  SNP = c("rs1", "rs2"),
  beta = c(1, 2),
  se = c(1, 2),
  effect_allele = c("A", "T")
)
random_df

## -----------------------------------------------------------------------------
random_exp_dat <- format_data(random_df, type = "exposure")
random_exp_dat

## ----eval=FALSE---------------------------------------------------------------
# remotes::install_github("MRCIEU/MRInstruments")

## -----------------------------------------------------------------------------
library(MRInstruments)
data(gwas_catalog)
head(gwas_catalog)

## ----eval=FALSE---------------------------------------------------------------
# bmi_gwas <-
#   subset(gwas_catalog,
#          grepl("Speliotes", Author) &
#            Phenotype == "Body mass index")
# bmi_exp_dat <- format_data(bmi_gwas)

## -----------------------------------------------------------------------------
data(metab_qtls)
head(metab_qtls)

## -----------------------------------------------------------------------------
ala_exp_dat <- format_metab_qtls(subset(metab_qtls, phenotype == "Ala"))

## -----------------------------------------------------------------------------
data(proteomic_qtls)
head(proteomic_qtls)

## ----warning=FALSE------------------------------------------------------------
apoh_exp_dat <-
  format_proteomic_qtls(subset(proteomic_qtls, analyte == "ApoH"))

## -----------------------------------------------------------------------------
data(gtex_eqtl)
head(gtex_eqtl)

## -----------------------------------------------------------------------------
irak1bp1_exp_dat <-
  format_gtex_eqtl(subset(
    gtex_eqtl,
    gene_name == "IRAK1BP1" & tissue == "Adipose Subcutaneous"
  ))

## -----------------------------------------------------------------------------
data(aries_mqtl)
head(aries_mqtl)

## -----------------------------------------------------------------------------
cg25212131_exp_dat <-
  format_aries_mqtl(subset(aries_mqtl, cpg == "cg25212131" &
                             age == "Birth"))

## ----eval=FALSE---------------------------------------------------------------
# ieugwasr::api_status()

## ----eval=FALSE---------------------------------------------------------------
# ao <- available_outcomes()
# head(ao)

## ----eval=FALSE---------------------------------------------------------------
# bmi2014_exp_dat <- extract_instruments(outcomes = 'ieu-a-2')

## ----eval=FALSE---------------------------------------------------------------
# bmi_exp_dat <- clump_data(bmi2014_exp_dat)

