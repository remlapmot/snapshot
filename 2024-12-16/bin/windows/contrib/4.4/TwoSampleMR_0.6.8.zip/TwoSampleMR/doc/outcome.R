## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  cache = TRUE
)

## ----message=FALSE------------------------------------------------------------
library(TwoSampleMR)

## ----eval=FALSE, echo=FALSE---------------------------------------------------
# # Get data for the vignette
# ao <- available_outcomes()
# bmi_exp_dat <- extract_instruments(outcomes = 'ieu-a-2')
# chd_out_dat1 <- extract_outcome_data(
# 	snps = bmi_exp_dat$SNP,
# 	outcomes = 'ieu-a-7'
# )
# chd_out_dat2 <- extract_outcome_data(
# 	snps = c("rs234", "rs17097147"),
# 	outcomes = c('ieu-a-2', 'ieu-a-7')
# )
# save(ao, bmi_exp_dat, chd_out_dat1, chd_out_dat2, file = file.path("inst", "extdata", "vig_outcome.RData"), compress = "xz")

## ----echo=FALSE, eval=TRUE, warning=FALSE-------------------------------------
load(system.file("extdata", "vig_outcome.RData", package = "TwoSampleMR"))

## ----eval=FALSE---------------------------------------------------------------
# ao <- available_outcomes()

## -----------------------------------------------------------------------------
head(ao)

## -----------------------------------------------------------------------------
head(subset(ao, select = c(trait, id)))

## ----eval=FALSE---------------------------------------------------------------
# bmi_exp_dat <- extract_instruments(outcomes = 'ieu-a-2')

## -----------------------------------------------------------------------------
head(bmi_exp_dat)

## -----------------------------------------------------------------------------
ao[grepl("heart disease", ao$trait), ]

## ----eval=FALSE---------------------------------------------------------------
# chd_out_dat1 <- extract_outcome_data(
# 	snps = bmi_exp_dat$SNP,
# 	outcomes = 'ieu-a-7'
# )

## ----eval=FALSE---------------------------------------------------------------
# chd_out_dat2 <- extract_outcome_data(
# 	snps = c("rs234", "rs17097147"),
# 	outcomes = c('ieu-a-2', 'ieu-a-7')
# )

## ----eval=FALSE---------------------------------------------------------------
# outcome_dat <- read_outcome_data(
# 	snps = bmi_exp_dat$SNP,
# 	filename = "gwas_summary.csv",
# 	sep = ",",
# 	snp_col = "rsid",
# 	beta_col = "effect",
# 	se_col = "SE",
# 	effect_allele_col = "a1",
# 	other_allele_col = "a2",
# 	eaf_col = "a1_freq",
# 	pval_col = "p-value",
# 	units_col = "Units",
# 	gene_col = "Gene",
# 	samplesize_col = "n"
# )

