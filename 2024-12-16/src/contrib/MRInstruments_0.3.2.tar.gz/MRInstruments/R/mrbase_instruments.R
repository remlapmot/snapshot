#' Data frame of GWAS significant SNPs obtained from the EBI GWAS catalog
#'
#' Created from the MR-Base database 23/12/2017
#' The top hits (5e-8) are extracted from these files and then the 1kg European dataset is used to clump the top hits (rsq = 0.001, kb = 10000)
#'
#' @format A data frame with 29792 rows and 16 columns
#'	\describe{
#'       \item{exposure}{This phenotype also has units and details if they are necessary to distinguish different studies}
#'       \item{id.exposure}{id.exposure}
#'       \item{samplesize.exposure}{samplesize.exposure}
#'       \item{ncase.exposure}{ncase.exposure}
#'       \item{ncontrol.exposure}{ncontrol.exposure}
#'       \item{mr_keep.exposure}{mr_keep.exposure}
#'       \item{pval_origin.exposure}{pval_origin.exposure}
#'       \item{data_source.exposure}{data_source.exposure}
#'       \item{SNP}{SNP}
#'       \item{effect_allele.exposure}{effect_allele.exposure}
#'       \item{other_allele.exposure}{other_allele.exposure}
#'       \item{beta.exposure}{beta.exposure}
#'       \item{se.exposure}{se.exposure}
#'       \item{pval.exposure}{pval.exposure}
#'       \item{units.exposure}{units.exposure}
#'       \item{eaf.exposure}{eaf.exposure}
#'}
#' @source \url{http://www.mrbase.org}
"mrbase_instruments"
