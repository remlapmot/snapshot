library(testthat)
library(dd4d)

test_check("dd4d")
