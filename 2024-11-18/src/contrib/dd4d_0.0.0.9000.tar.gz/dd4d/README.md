# dd4d
 dummy data for dummies

# Tutorial

A [short tutorial](https://nbviewer.org/github/opensafely/mv-dummy-data/blob/main/prototype-report.html) on how this package works in the context of [the OpenSAFELY platform](https://www.opensafely.org/) is available [in a separate repository](https://github.com/opensafely/mv-dummy-data). It also includes some thoughts on how the package can be enhanced. The tutorial is out of date as the current API has been simplified and simulation operations are now fully vectorised (e.g., by using `n=..n` instead of `n=1`). 
