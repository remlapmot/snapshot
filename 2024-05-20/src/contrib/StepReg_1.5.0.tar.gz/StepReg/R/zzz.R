.onLoad <- function(libname, pkgname){
  Sys.setlocale("LC_CTYPE", "en_US.UTF-8")
}