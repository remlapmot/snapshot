#' tmsens: Sensitivity Analysis Using the Trimmed Mean Estimator
#'
#' This package implements sensitivity analysis using the trimmed mean estimator.
#'
#' @name tmsens-package
#' @aliases tmsens
"_PACKAGE"
