# TrialEmulation 0.0.3.26

* Improve documentation

* Add `estimand_type` argument

* Internal refactoring

# TrialEmulation 0.0.3.2

* Initial release to CRAN

# TrialEmulation 0.0.2.x

* Further feature development and code improvement

* Implemented case-control sampling

* Implemented `predict()` method

* Package tests and CI pipeline on github

# TrialEmulation 0.0.1

* Initial development by Roonak Rezvani as internship project

* Data preparation and model fitting functions for sequence of target trials

* Support for large data using `biglm`, `data.table` and chunked processing
