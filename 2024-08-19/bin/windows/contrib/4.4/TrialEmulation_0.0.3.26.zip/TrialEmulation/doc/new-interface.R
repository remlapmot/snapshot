## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(TrialEmulation)

## -----------------------------------------------------------------------------
trial_pp <- trial_sequence(estimand = "PP") # Per-protocol
trial_itt <- trial_sequence(estimand = "ITT") # Intention-to-treat

## -----------------------------------------------------------------------------
trial_pp_dir <- file.path(tempdir(), "trial_pp")
dir.create(trial_pp_dir)
trial_itt_dir <- file.path(tempdir(), "trial_itt")
dir.create(trial_itt_dir)

## -----------------------------------------------------------------------------
data("data_censored")
trial_pp <- trial_pp |>
  set_data(
    data = data_censored,
    id = "id",
    period = "period",
    treatment = "treatment",
    outcome = "outcome",
    eligible = "eligible"
  )

# Function style without pipes
trial_itt <- set_data(
  trial_itt,
  data = data_censored,
  id = "id",
  period = "period",
  treatment = "treatment",
  outcome = "outcome",
  eligible = "eligible"
)

## -----------------------------------------------------------------------------
trial_itt

## -----------------------------------------------------------------------------
trial_pp <- trial_pp |>
  set_switch_weight_model(
    numerator = ~ age + x1 + x3,
    denominator = ~age,
    model_fitter = stats_glm_logit(save_path = file.path(trial_pp_dir, "switch_models"))
  )
trial_pp

## -----------------------------------------------------------------------------
trial_pp <- trial_pp |>
  set_censor_weight_model(
    censor_event = "censored",
    numerator = ~ x1 + x2 + x3,
    denominator = ~x2,
    pool_models = "none",
    model_fitter = stats_glm_logit(save_path = file.path(trial_pp_dir, "switch_models"))
  )
trial_pp

## -----------------------------------------------------------------------------
trial_itt <- set_censor_weight_model(
  trial_itt,
  censor_event = "censored",
  numerator = ~ x1 + x2 + x3,
  denominator = ~x2,
  pool_models = "numerator",
  model_fitter = stats_glm_logit(save_path = file.path(trial_itt_dir, "switch_models"))
)
trial_itt

## -----------------------------------------------------------------------------
trial_pp <- trial_pp |> calculate_weights()
trial_pp


trial_itt <- calculate_weights(trial_itt)

## -----------------------------------------------------------------------------
show_weight_models(trial_itt)

## ----eval = FALSE-------------------------------------------------------------
#  trial_pp <- set_outcome_model(trial_pp)
#  trial_itt <- set_outcome_model(trial_itt, adjustment_terms = ~ x1 + x2)

## -----------------------------------------------------------------------------
trial_pp <- trial_pp |>
  set_expansion_options(
    output = save_to_csv(file.path(trial_pp_dir, "trial_csvs")),
    chunk_size = 500
  )

trial_itt <- set_expansion_options(
  trial_itt,
  output = save_to_csv(file.path(trial_itt_dir, "trial_csvs")),
  chunk_size = 500
)

trial_itt <- set_expansion_options(
  trial_itt,
  output = save_to_datatable(),
  chunk_size = 500
)

trial_itt <- set_expansion_options(
  trial_itt,
  output = save_to_duckdb(file.path(trial_itt_dir, "trial_duckdb")),
  chunk_size = 500
)

## -----------------------------------------------------------------------------
trial_pp <- expand_trials(trial_pp)
trial_itt <- expand_trials(trial_itt)

## -----------------------------------------------------------------------------
trial_pp@expansion
trial_itt@expansion

