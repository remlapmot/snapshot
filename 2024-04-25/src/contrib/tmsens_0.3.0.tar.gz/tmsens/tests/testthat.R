library(testthat)
library(tmsens)


test_check("tmsens")
