# knitexercise 0.3.0

* Bump version of **roxygen2** used to create the package documentation

# knitexercise 0.2.0

* Bump minimum required version of R to be 3.6.0

# knitexercise 0.1.0

* First version of package
