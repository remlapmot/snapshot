library(testthat)
library(OneSampleMR)

test_check("OneSampleMR")
