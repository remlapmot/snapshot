# Using globalVariables to avoid no visible binding for global variable RCMD check notes.

utils::globalVariables(c("ambiguousA", "ambiguousB", "ea", "keep", "n", "nea", "p", "rsid","eaf", ".", "%>%", "bf_conv","i","index", "variantid","mtext","par", "tibble", "chr", "position","meta", "as_tibble", "pchisq","mutate","se",".data"))